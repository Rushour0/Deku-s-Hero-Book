# Deku's Hero Book
Making an app of heroes' details - Deku's Hero Analysis Book

In the building process!
